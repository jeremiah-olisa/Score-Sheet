A Pen created at CodePen.io. You can find this one at https://codepen.io/birjolaxew/pen/qOXovL.

 Inspired by [a dribbble](https://dribbble.com/shots/2287561-Login-Sign-Up-Interface) by Gal Shir