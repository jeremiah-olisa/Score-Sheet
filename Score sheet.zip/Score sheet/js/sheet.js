function calc() {
	var a = parseInt(document.getElementById('cw1').value);
	var b = parseInt(document.getElementById('a1').value);
	var c = parseInt(document.getElementById('t1').value);
	var d = parseInt(document.getElementById('e1').value);
	var Total = a + b + c + d;
	document.getElementById('total1').innerHTML=Total;

	var aa = parseInt(document.getElementById('cw2').value);
	var ba = parseInt(document.getElementById('a2').value);
	var ca = parseInt(document.getElementById('t2').value);
	var da = parseInt(document.getElementById('e2').value);
	var Total2 = aa + ba + ca + da;
	document.getElementById('total2').innerHTML=Total2;

	
}
function addRow() {
	var template = document.getElementById('rowTemplate')
	tbl = document.getElementById('myTable')
	td_slNo = template.content.querySelectorAll("td")[0],
	tr_count = tbl.rows.length;
	td_slNo.textContent = tr_count;
	var clone = document.importNode(template.content, true);
	tbl.appendChild(clone);
}
function scalc() {
	var n = 0

	var cw1 = parseInt(document.getElementById('cw1').value);
	var a1 = parseInt(document.getElementById('a1').value);
	var t1 = parseInt(document.getElementById('t1').value);
	var e1 = parseInt(document.getElementById('e1').value);
	var Total1 = cw1 + a1 + t1 + e1;
	document.getElementById('total1').innerHTML=Total1;

	if(Total1 == 0 || Total1 <= 39){
		document.getElementById('grade1').innerHTML="F"
	}

	else if(Total1 == 40 || Total1 <= 44){
		document.getElementById('grade1').innerHTML="E"
	}

	else if(Total1 == 45 || Total1 <= 49){
		document.getElementById('grade1').innerHTML="D"
	}

	else if(Total1 == 50 || Total1 <= 59){
		document.getElementById('grade1').innerHTML="C"
	}

	else if(Total1 == 60 || Total1 <= 69){
		document.getElementById('grade1').innerHTML="B"
	}

	else if(Total1 == 70 || Total1 <= 84){
		document.getElementById('grade1').innerHTML="A"
	}

	else if(Total1 == 85 || Total1 <= 100){
		document.getElementById('grade1').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw1 > 10 || cw1 < 0) {
		document.getElementById('cw1').style.border = "1px solid #F94F4F"
	}
	if (a1 > 10 || a1 < 0) {
		document.getElementById('a1').style.border = "1px solid #F94F4F"
	}
	if (t1 > 20 || t1 < 0) {
		document.getElementById('t1').style.border = "1px solid #F94F4F"
	}
	if (e1 > 60 || e1 < 0) {
		document.getElementById('e1').style.border = "1px solid #F94F4F"
	}
	
	var cw2 = parseInt(document.getElementById('cw2').value);
	var a2 = parseInt(document.getElementById('a2').value);
	var t2 = parseInt(document.getElementById('t2').value);
	var e2 = parseInt(document.getElementById('e2').value);
	var Total2 = cw2 + a2 + t2 + e2;
	document.getElementById('total2').innerHTML=Total2;

	if(Total2 == 0 || Total2 <= 39){
			document.getElementById('grade2').innerHTML="F"
		}

		else if(Total2 == 40 || Total1 <= 44){
			document.getElementById('grade2').innerHTML="E"
		}

		else if(Total2 == 45 || Total2 <= 49){
			document.getElementById('grade2').innerHTML="D"
		}

		else if(Total2 == 50 || Total2 <= 59){
			document.getElementById('grade2').innerHTML="C"
		}

		else if(Total2 == 60 || Total1 <= 69){
			document.getElementById('grade2').innerHTML="B"
		}

		else if(Total2 == 70 || Total2 <= 84){
			document.getElementById('grade2').innerHTML="A"
		}

		else if(Total2 == 85 || Total1 <= 100){
			document.getElementById('grade2').innerHTML="A<sup>+</sup>"
		}

		else{
			
		} 
		if (cw2 > 10 || cw2 < 0) {
			document.getElementById('cw2').style.border = "1px solid #F94F4F"
		}
		if (a2 > 10 || a2 < 0) {
			document.getElementById('a2').style.border = "1px solid #F94F4F"
		}
		if (t2 > 20 || t2 < 0) {
			document.getElementById('t2').style.border = "1px solid #F94F4F"
		}
		if (e2 > 60 || e2 < 0) {
			document.getElementById('e2').style.border = "1px solid #F94F4F"
		}

	var cw3 = parseInt(document.getElementById('cw3').value);
	var a3 = parseInt(document.getElementById('a3').value);
	var t3 = parseInt(document.getElementById('t3').value);
	var e3 = parseInt(document.getElementById('e3').value);
	var Total3 = cw3 + a3 + t3 + e3;
	document.getElementById('total3').innerHTML=Total3;

	if(Total3 == 0 || Total3 <= 39){
		document.getElementById('grade3').innerHTML="F"
	}

	else if(Total3 == 40 || Total3 <= 44){
		document.getElementById('grade3').innerHTML="E"
	}

	else if(Total3 == 45 || Total3 <= 49){
		document.getElementById('grade3').innerHTML="D"
	}

	else if(Total3 == 50 || Total3 <= 59){
		document.getElementById('grade3').innerHTML="C"
	}

	else if(Total3 == 60 || Total3<= 69){
		document.getElementById('grade3').innerHTML="B"
	}

	else if(Total3 == 70 || Total3 <= 84){
		document.getElementById('grade3').innerHTML="A"
	}

	else if(Total3 == 85 || Total3 <= 100){
		document.getElementById('grade3').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw3 > 10 || cw3 < 0) {
		document.getElementById('cw3').style.border = "1px solid #F94F4F"
	}
	if (a3 > 10 || a3 < 0) {
		document.getElementById('a3').style.border = "1px solid #F94F4F"
	}
	if (t3 > 20 || t3 < 0) {
		document.getElementById('t3').style.border = "1px solid #F94F4F"
	}
	if (e3 > 60 || e3 < 0) {
		document.getElementById('e3').style.border = "1px solid #F94F4F"
	}

	var cw4 = parseInt(document.getElementById('cw4').value);
	var a4 = parseInt(document.getElementById('a4').value);
	var t4 = parseInt(document.getElementById('t4').value);
	var e4 = parseInt(document.getElementById('e4').value);
	var Total4 = cw4 + a4 + t4 + e4;
	document.getElementById('total4').innerHTML=Total4;

	if(Total4 == 0 || Total4 <= 39){
		document.getElementById('grade4').innerHTML="F"
	}

	else if(Total4 == 40 || Total4 <= 44){
		document.getElementById('grade4').innerHTML="E"
	}

	else if(Total4 == 45 || Total4 <= 49){
		document.getElementById('grade4').innerHTML="D"
	}

	else if(Total4 == 50 || Total4 <= 59){
		document.getElementById('grade4').innerHTML="C"
	}

	else if(Total4 == 60 || Total4 <= 69){
		document.getElementById('grade4').innerHTML="B"
	}

	else if(Total4 == 70 || Total4 <= 84){
		document.getElementById('grade4').innerHTML="A"
	}

	else if(Total4 == 85 || Total4 <= 100){
		document.getElementById('grade4').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw4 > 10 || cw4 < 0) {
		document.getElementById('cw4').style.border = "1px solid #F94F4F"
	}
	if (a4 > 10 || a4 < 0) {
		document.getElementById('a4').style.border = "1px solid #F94F4F"
	}
	if (t4 > 20 || t4 < 0) {
		document.getElementById('t4').style.border = "1px solid #F94F4F"
	}
	if (e4 > 60 || e4 < 0) {
		document.getElementById('e4').style.border = "1px solid #F94F4F"
	}

	var cw5 = parseInt(document.getElementById('cw5').value);
	var a5 = parseInt(document.getElementById('a5').value);
	var t5 = parseInt(document.getElementById('t5').value);
	var e5 = parseInt(document.getElementById('e5').value);
	var Total5 = cw5 + a5 + t5 + e5;
	document.getElementById('total5').innerHTML=Total5;

	if(Total1== 0 || Total5<= 39){
		document.getElementById('grade5').innerHTML="F"
	}

	else if(Total5== 40 || Total5<= 44){
		document.getElementById('grade5').innerHTML="E"
	}

	else if(Total5== 45 || Total5<= 49){
		document.getElementById('grade5').innerHTML="D"
	}

	else if(Total5== 50 || Total5<= 59){
		document.getElementById('grade5').innerHTML="C"
	}

	else if(Total5== 60 || Total5<= 69){
		document.getElementById('grade5').innerHTML="B"
	}

	else if(Total5== 70 || Total5<= 84){
		document.getElementById('grade5').innerHTML="A"
	}

	else if(Total5== 85 || Total5<= 100){
		document.getElementById('grade5').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw5> 10 || cw5< 0) {
		document.getElementById('cw5').style.border = "1px solid #F94F4F"
	}
	if (a5> 10 || a5< 0) {
		document.getElementById('a5').style.border = "1px solid #F94F4F"
	}
	if (t5> 20 || t5< 0) {
		document.getElementById('t5').style.border = "1px solid #F94F4F"
	}
	if (e5> 60 || e5< 0) {
		document.getElementById('e5').style.border = "1px solid #F94F4F"
	}

	var cw6 = parseInt(document.getElementById('cw6').value);
	var a6 = parseInt(document.getElementById('a6').value);
	var t6 = parseInt(document.getElementById('t6').value);
	var e6 = parseInt(document.getElementById('e6').value);
	var Total6 = cw6 + a6 + t6 + e6;
	document.getElementById('total6').innerHTML=Total6;

    if(Total6 == 0 || Total6 <= 39){
		document.getElementById('grade6').innerHTML="F"
	}

	else if(Total6 == 40 || Total6 <= 44){
		document.getElementById('grade6').innerHTML="E"
	}

	else if(Total6 == 45 || Total6 <= 49){
		document.getElementById('grade6').innerHTML="D"
	}

	else if(Total6 == 50 || Total6 <= 59){
		document.getElementById('grade6').innerHTML="C"
	}

	else if(Total6 == 60 || Total6 <= 69){
		document.getElementById('grade6').innerHTML="B"
	}

	else if(Total6 == 70 || Total6 <= 84){
		document.getElementById('grade6').innerHTML="A"
	}

	else if(Total6 == 85 || Total6 <= 100){
		document.getElementById('grade6').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw6 > 10 || cw6 < 0) {
		document.getElementById('cw6').style.border = "1px solid #F94F4F"
	}
	if (a6 > 10 || a6 < 0) {
		document.getElementById('a6').style.border = "1px solid #F94F4F"
	}
	if (t6 > 20 || t6 < 0) {
		document.getElementById('t6').style.border = "1px solid #F94F4F"
	}
	if (e6 > 60 || e6 < 0) {
		document.getElementById('e6').style.border = "1px solid #F94F4F"
	}

	var cw7 = parseInt(document.getElementById('cw7').value);
	var a7 = parseInt(document.getElementById('a7').value);
	var t7 = parseInt(document.getElementById('t7').value);
	var e7 = parseInt(document.getElementById('e7').value);
	var Total7 = cw7 + a7 + t7 + e7;
	document.getElementById('total7').innerHTML=Total7;

if(Total7 == 0 || Total7 <= 39){
		document.getElementById('grade7').innerHTML="F"
	}

	else if(Total7 == 40 || Total7 <= 44){
		document.getElementById('grade7').innerHTML="E"
	}

	else if(Total7 == 45 || Total7 <= 49){
		document.getElementById('grade7').innerHTML="D"
	}

	else if(Total7 == 50 || Total7 <= 59){
		document.getElementById('grade7').innerHTML="C"
	}

	else if(Total7 == 60 || Total7 <= 69){
		document.getElementById('grade7').innerHTML="B"
	}

	else if(Total7 == 70 || Total7 <= 84){
		document.getElementById('grade7').innerHTML="A"
	}

	else if(Total7 == 85 || Total7 <= 100){
		document.getElementById('grade7').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw7 > 10 || cw7 < 0) {
		document.getElementById('cw7').style.border = "1px solid #F94F4F"
	}
	if (a7 > 10 || a7 < 0) {
		document.getElementById('a7').style.border = "1px solid #F94F4F"
	}
	if (t7 > 20 || t7 < 0) {
		document.getElementById('t7').style.border = "1px solid #F94F4F"
	}
	if (e7 > 60 || e7 < 0) {
		document.getElementById('e7').style.border = "1px solid #F94F4F"
	}

	var cw8 = parseInt(document.getElementById('cw8').value);
	var a8 = parseInt(document.getElementById('a8').value);
	var t8 = parseInt(document.getElementById('t8').value);
	var e8 = parseInt(document.getElementById('e8').value);
	var Total8 = cw8 + a8 + t8 + e8;
	document.getElementById('total8').innerHTML=Total8;

	if(Total8 == 0 || Total8 <= 39){
		document.getElementById('grade8').innerHTML="F"
	}

	else if(Total8 == 40 || Total8 <= 44){
		document.getElementById('grade8').innerHTML="E"
	}

	else if(Total8 == 45 || Total8 <= 49){
		document.getElementById('grade8').innerHTML="D"
	}

	else if(Total8 == 50 || Total8 <= 59){
		document.getElementById('grade8').innerHTML="C"
	}

	else if(Total8 == 60 || Total8 <= 69){
		document.getElementById('grade8').innerHTML="B"
	}

	else if(Total8 == 70 || Total8 <= 84){
		document.getElementById('grade8').innerHTML="A"
	}

	else if(Total8 == 85 || Total8 <= 100){
		document.getElementById('grade8').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw8 > 10 || cw8 < 0) {
		document.getElementById('cw8').style.border = "1px solid #F94F4F"
	}
	if (a8 > 10 || a8 < 0) {
		document.getElementById('a8').style.border = "1px solid #F94F4F"
	}
	if (t8 > 20 || t8 < 0) {
		document.getElementById('t8').style.border = "1px solid #F94F4F"
	}
	if (e8 > 60 || e8 < 0) {
		document.getElementById('e8').style.border = "1px solid #F94F4F"
	}

	var cw9 = parseInt(document.getElementById('cw9').value);
	var a9 = parseInt(document.getElementById('a9').value);
	var t9 = parseInt(document.getElementById('t9').value);
	var e9 = parseInt(document.getElementById('e9').value);
	var Total9 = cw9 + a9 + t9 + e9;
	document.getElementById('total9').innerHTML=Total9;

	if(Total9 == 0 || Total9 <= 39){
		document.getElementById('grade9').innerHTML="F"
	}

	else if(Total9 == 40 || Total9 <= 44){
		document.getElementById('grade9').innerHTML="E"
	}

	else if(Total9 == 45 || Total9 <= 49){
		document.getElementById('grade9').innerHTML="D"
	}

	else if(Total9 == 50 || Total9 <= 59){
		document.getElementById('grade9').innerHTML="C"
	}

	else if(Total9 == 60 || Total9 <= 69){
		document.getElementById('grade9').innerHTML="B"
	}

	else if(Total9 == 70 || Total9 <= 84){
		document.getElementById('grade9').innerHTML="A"
	}

	else if(Total9 == 85 || Total9 <= 100){
		document.getElementById('grade9').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw9 > 10 || cw9 < 0) {
		document.getElementById('cw9').style.border = "1px solid #F94F4F"
	}
	if (a9 > 10 || a9 < 0) {
		document.getElementById('a9').style.border = "1px solid #F94F4F"
	}
	if (t9 > 20 || t9 < 0) {
		document.getElementById('t9').style.border = "1px solid #F94F4F"
	}
	if (e9 > 60 || e9 < 0) {
		document.getElementById('e9').style.border = "1px solid #F94F4F"
	}

	var cw10 = parseInt(document.getElementById('cw10').value);
	var a10 = parseInt(document.getElementById('a10').value);
	var t10 = parseInt(document.getElementById('t10').value);
	var e10 = parseInt(document.getElementById('e10').value);
	var Total10 = cw10 + a10 + t10 + e10;
	document.getElementById('total10').innerHTML=Total10;

	if(Total10 == 0 || Total10 <= 39){
		document.getElementById('grade10').innerHTML="F"
	}

	else if(Total10 == 40 || Total10 <= 44){
		document.getElementById('grade10').innerHTML="E"
	}

	else if(Total10 == 45 || Total10 <= 49){
		document.getElementById('grade10').innerHTML="D"
	}

	else if(Total10 == 50 || Total10 <= 59){
		document.getElementById('grade10').innerHTML="C"
	}

	else if(Total10 == 60 || Total10 <= 69){
		document.getElementById('grade10').innerHTML="B"
	}

	else if(Total10 == 70 || Total10 <= 84){
		document.getElementById('grade10').innerHTML="A"
	}

	else if(Total10 == 85 || Total10 <= 100){
		document.getElementById('grade10').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw10 > 10 || cw10 < 0) {
		document.getElementById('cw10').style.border = "1px solid #F94F4F"
	}
	if (a10 > 10 || a10 < 0) {
		document.getElementById('a10').style.border = "1px solid #F94F4F"
	}
	if (t10 > 20 || t10 < 0) {
		document.getElementById('t10').style.border = "1px solid #F94F4F"
	}
	if (e10 > 60 || e10 < 0) {
		document.getElementById('e10').style.border = "1px solid #F94F4F"
	}

	var cw11 = parseInt(document.getElementById('cw11').value);
	var a11 = parseInt(document.getElementById('a11').value);
	var t11 = parseInt(document.getElementById('t11').value);
	var e11 = parseInt(document.getElementById('e11').value);
	var Total11 = cw11 + a11 + t11 + e11;
	document.getElementById('total11').innerHTML=Total11;

	if(Total11 == 0 || Total11 <= 39){
		document.getElementById('grade11').innerHTML="F"
	}

	else if(Total11 == 40 || Total11 <= 44){
		document.getElementById('grade11').innerHTML="E"
	}

	else if(Total11 == 45 || Total11 <= 49){
		document.getElementById('grade11').innerHTML="D"
	}

	else if(Total11 == 50 || Total11 <= 59){
		document.getElementById('grade11').innerHTML="C"
	}

	else if(Total11 == 60 || Total11 <= 69){
		document.getElementById('grade11').innerHTML="B"
	}

	else if(Total11 == 70 || Total11 <= 84){
		document.getElementById('grade11').innerHTML="A"
	}

	else if(Total11 == 85 || Total11 <= 100){
		document.getElementById('grade11').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw11 > 10 || cw11 < 0) {
		document.getElementById('cw11').style.border = "1px solid #F94F4F"
	}
	if (a11 > 10 || a11 < 0) {
		document.getElementById('a11').style.border = "1px solid #F94F4F"
	}
	if (t11 > 20 || t11 < 0) {
		document.getElementById('t11').style.border = "1px solid #F94F4F"
	}
	if (e11 > 60 || e11 < 0) {
		document.getElementById('e11').style.border = "1px solid #F94F4F"
	}

	var cw12 = parseInt(document.getElementById('cw12').value);
	var a12 = parseInt(document.getElementById('a12').value);
	var t12 = parseInt(document.getElementById('t12').value);
	var e12 = parseInt(document.getElementById('e12').value);
	var Total12 = cw12 + a12 + t12 + e12;
	document.getElementById('total12').innerHTML=Total12;

	if(Total12 == 0 || Total12 <= 39){
		document.getElementById('grade12').innerHTML="F"
	}

	else if(Total12 == 40 || Total12 <= 44){
		document.getElementById('grade12').innerHTML="E"
	}

	else if(Total12 == 45 || Total12 <= 49){
		document.getElementById('grade12').innerHTML="D"
	}

	else if(Total12 == 50 || Total12 <= 59){
		document.getElementById('grade12').innerHTML="C"
	}

	else if(Total12 == 60 || Total12 <= 69){
		document.getElementById('grade12').innerHTML="B"
	}

	else if(Total12 == 70 || Total12 <= 84){
		document.getElementById('grade12').innerHTML="A"
	}

	else if(Total12 == 85 || Total12 <= 100){
		document.getElementById('grade12').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw12 > 10 || cw12 < 0) {
		document.getElementById('cw12').style.border = "1px solid #F94F4F"
	}
	if (a12 > 10 || a12 < 0) {
		document.getElementById('a12').style.border = "1px solid #F94F4F"
	}
	if (t12 > 20 || t12 < 0) {
		document.getElementById('t12').style.border = "1px solid #F94F4F"
	}
	if (e12 > 60 || e12 < 0) {
		document.getElementById('e12').style.border = "1px solid #F94F4F"
	}

	var cw13 = parseInt(document.getElementById('cw13').value);
	var a13 = parseInt(document.getElementById('a13').value);
	var t13 = parseInt(document.getElementById('t13').value);
	var e13 = parseInt(document.getElementById('e13').value);
	var Total13 = cw13 + a13 + t13 + e13;
	document.getElementById('total13').innerHTML=Total13;

	if(Total13 == 0 || Total13 <= 39){
		document.getElementById('grade13').innerHTML="F"
	}

	else if(Total13 == 40 || Total13 <= 44){
		document.getElementById('grade13').innerHTML="E"
	}

	else if(Total13 == 45 || Total13 <= 49){
		document.getElementById('grade13').innerHTML="D"
	}

	else if(Total13 == 50 || Total13 <= 59){
		document.getElementById('grade13').innerHTML="C"
	}

	else if(Total13 == 60 || Total13 <= 69){
		document.getElementById('grade13').innerHTML="B"
	}

	else if(Total13 == 70 || Total13 <= 84){
		document.getElementById('grade13').innerHTML="A"
	}

	else if(Total13 == 85 || Total13 <= 100){
		document.getElementById('grade13').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw13 > 10 || cw13 < 0) {
		document.getElementById('cw13').style.border = "1px solid #F94F4F"
	}
	if (a13 > 10 || a13 < 0) {
		document.getElementById('a13').style.border = "1px solid #F94F4F"
	}
	if (t13 > 20 || t13 < 0) {
		document.getElementById('t13').style.border = "1px solid #F94F4F"
	}
	if (e13 > 60 || e13 < 0) {
		document.getElementById('e13').style.border = "1px solid #F94F4F"
	}


	var cw14 = parseInt(document.getElementById('cw14').value);
	var a14 = parseInt(document.getElementById('a14').value);
	var t14 = parseInt(document.getElementById('t14').value);
	var e14 = parseInt(document.getElementById('e14').value);
	var Total14 = cw14 + a14 + t14 + e14;
	document.getElementById('total14').innerHTML=Total14;

		if(Total14 == 0 || Total14 <= 39){
		document.getElementById('grade14').innerHTML="F"
	}

	else if(Total14 == 40 || Total14 <= 44){
		document.getElementById('grade14').innerHTML="E"
	}

	else if(Total14 == 45 || Total14 <= 49){
		document.getElementById('grade14').innerHTML="D"
	}

	else if(Total14 == 50 || Total14 <= 59){
		document.getElementById('grade14').innerHTML="C"
	}

	else if(Total14 == 60 || Total14 <= 69){
		document.getElementById('grade14').innerHTML="B"
	}

	else if(Total14 == 70 || Total14 <= 84){
		document.getElementById('grade14').innerHTML="A"
	}

	else if(Total14 == 85 || Total14 <= 100){
		document.getElementById('grade14').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw14 > 10 || cw14 < 0) {
		document.getElementById('cw14').style.border = "1px solid #F94F4F"
	}
	if (a14 > 10 || a14 < 0) {
		document.getElementById('a14').style.border = "1px solid #F94F4F"
	}
	if (t14 > 20 || t14 < 0) {
		document.getElementById('t14').style.border = "1px solid #F94F4F"
	}
	if (e14 > 60 || e14 < 0) {
		document.getElementById('e14').style.border = "1px solid #F94F4F"
	}

	var cw15 = parseInt(document.getElementById('cw15').value);
	var a15 = parseInt(document.getElementById('a15').value);
	var t15 = parseInt(document.getElementById('t15').value);
	var e15 = parseInt(document.getElementById('e15').value);
	var Total15 = cw15 + a15 + t15 + e15;
	document.getElementById('total15').innerHTML=Total15;

		if(Total15 == 0 || Total15 <= 39){
		document.getElementById('grade15').innerHTML="F"
	}

	else if(Total15 == 40 || Total15 <= 44){
		document.getElementById('grade15').innerHTML="E"
	}

	else if(Total15 == 45 || Total15 <= 49){
		document.getElementById('grade15').innerHTML="D"
	}

	else if(Total15 == 50 || Total15 <= 59){
		document.getElementById('grade15').innerHTML="C"
	}

	else if(Total15 == 60 || Total15 <= 69){
		document.getElementById('grade15').innerHTML="B"
	}

	else if(Total15 == 70 || Total15 <= 84){
		document.getElementById('grade15').innerHTML="A"
	}

	else if(Total15 == 85 || Total15 <= 1100){
		document.getElementById('grade15').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw15 > 10 || cw15 < 0) {
		document.getElementById('cw15').style.border = "1px solid #F94F4F"
	}
	if (a15 > 10 || a15 < 0) {
		document.getElementById('a15').style.border = "1px solid #F94F4F"
	}
	if (t15 > 20 || t15 < 0) {
		document.getElementById('t15').style.border = "1px solid #F94F4F"
	}
	if (e15 > 60 || e15 < 0) {
		document.getElementById('e15').style.border = "1px solid #F94F4F"
	}

	var cw16 = parseInt(document.getElementById('cw16').value);
	var a16 = parseInt(document.getElementById('a16').value);
	var t16 = parseInt(document.getElementById('t16').value);
	var e16 = parseInt(document.getElementById('e16').value);
	var Total16 = cw16 + a16 + t16 + e16;
	document.getElementById('total16').innerHTML=Total16;

		if(Total16 == 0 || Total16 <= 39){
		document.getElementById('grade16').innerHTML="F"
	}

	else if(Total16 == 40 || Total16 <= 44){
		document.getElementById('grade16').innerHTML="E"
	}

	else if(Total16 == 45 || Total16 <= 49){
		document.getElementById('grade16').innerHTML="D"
	}

	else if(Total16 == 50 || Total16 <= 59){
		document.getElementById('grade16').innerHTML="C"
	}

	else if(Total16 == 60 || Total16 <= 69){
		document.getElementById('grade16').innerHTML="B"
	}

	else if(Total16 == 70 || Total16 <= 84){
		document.getElementById('grade16').innerHTML="A"
	}

	else if(Total16 == 85 || Total16 <= 100){
		document.getElementById('grade16').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw16 > 10 || cw16 < 0) {
		document.getElementById('cw16').style.border = "1px solid #F94F4F"
	}
	if (a16 > 10 || a16 < 0) {
		document.getElementById('a16').style.border = "1px solid #F94F4F"
	}
	if (t16 > 20 || t16 < 0) {
		document.getElementById('t16').style.border = "1px solid #F94F4F"
	}
	if (e16 > 60 || e16 < 0) {
		document.getElementById('e16').style.border = "1px solid #F94F4F"
	}



	var cw17 = parseInt(document.getElementById('cw17').value);
	var a17 = parseInt(document.getElementById('a17').value);
	var t17 = parseInt(document.getElementById('t17').value);
	var e17 = parseInt(document.getElementById('e17').value);
	var Total17 = cw17 + a17 + t17 + e17;
	document.getElementById('total17').innerHTML=Total17;

		if(Total17 == 0 || Total17 <= 39){
		document.getElementById('grade17').innerHTML="F"
	}

	else if(Total17 == 40 || Total17 <= 44){
		document.getElementById('grade17').innerHTML="E"
	}

	else if(Total17 == 45 || Total17 <= 49){
		document.getElementById('grade17').innerHTML="D"
	}

	else if(Total17 == 50 || Total17 <= 59){
		document.getElementById('grade17').innerHTML="C"
	}

	else if(Total17 == 60 || Total17 <= 69){
		document.getElementById('grade17').innerHTML="B"
	}

	else if(Total17 == 70 || Total17 <= 84){
		document.getElementById('grade17').innerHTML="A"
	}

	else if(Total17 == 85 || Total17 <= 100){
		document.getElementById('grade17').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw17 > 10 || cw17 < 0) {
		document.getElementById('cw17').style.border = "1px solid #F94F4F"
	}
	if (a17 > 10 || a17 < 0) {
		document.getElementById('a17').style.border = "1px solid #F94F4F"
	}
	if (t17 > 20 || t17 < 0) {
		document.getElementById('t17').style.border = "1px solid #F94F4F"
	}
	if (e17 > 60 || e17 < 0) {
		document.getElementById('e17').style.border = "1px solid #F94F4F"
	}


	var cw18 = parseInt(document.getElementById('cw18').value);
	var a18 = parseInt(document.getElementById('a18').value);
	var t18 = parseInt(document.getElementById('t18').value);
	var e18 = parseInt(document.getElementById('e18').value);
	var Total18 = cw18 + a18 + t18 + e18;
	document.getElementById('total18').innerHTML=Total18;

	if(Total18 == 0 || Total18 <= 39){
		document.getElementById('grade18').innerHTML="F"
	}

	else if(Total18 == 40 || Total18 <= 44){
		document.getElementById('grade18').innerHTML="E"
	}

	else if(Total18 == 45 || Total18 <= 49){
		document.getElementById('grade18').innerHTML="D"
	}

	else if(Total18 == 50 || Total18 <= 59){
		document.getElementById('grade18').innerHTML="C"
	}

	else if(Total18 == 60 || Total18 <= 69){
		document.getElementById('grade18').innerHTML="B"
	}

	else if(Total18 == 70 || Total18 <= 84){
		document.getElementById('grade18').innerHTML="A"
	}

	else if(Total18 == 85 || Total18 <= 100){
		document.getElementById('grade18').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw18 > 10 || cw18 < 0) {
		document.getElementById('cw18').style.border = "1px solid #F94F4F"
	}
	if (a18 > 10 || a18 < 0) {
		document.getElementById('a18').style.border = "1px solid #F94F4F"
	}
	if (t18 > 20 || t18 < 0) {
		document.getElementById('t18').style.border = "1px solid #F94F4F"
	}
	if (e18 > 60 || e18 < 0) {
		document.getElementById('e18').style.border = "1px solid #F94F4F"
	}


	var cw19 = parseInt(document.getElementById('cw19').value);
	var a19 = parseInt(document.getElementById('a19').value);
	var t19 = parseInt(document.getElementById('t19').value);
	var e19 = parseInt(document.getElementById('e19').value);
	var Total19 = cw19 + a19 + t19 + e19;
	document.getElementById('total19').innerHTML=Total19;

	if(Total19 == 0 || Total19 <= 39){
		document.getElementById('grade19').innerHTML="F"
	}

	else if(Total19 == 40 || Total19 <= 44){
		document.getElementById('grade19').innerHTML="E"
	}

	else if(Total19 == 45 || Total19 <= 49){
		document.getElementById('grade19').innerHTML="D"
	}

	else if(Total19 == 50 || Total19 <= 59){
		document.getElementById('grade19').innerHTML="C"
	}

	else if(Total19 == 60 || Total19 <= 69){
		document.getElementById('grade19').innerHTML="B"
	}

	else if(Total19 == 70 || Total19 <= 84){
		document.getElementById('grade19').innerHTML="A"
	}

	else if(Total19 == 85 || Total19 <= 100){
		document.getElementById('grade19').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw19 > 10 || cw19 < 0) {
		document.getElementById('cw19').style.border = "1px solid #F94F4F"
	}
	if (a19 > 10 || a19 < 0) {
		document.getElementById('a19').style.border = "1px solid #F94F4F"
	}
	if (t19 > 20 || t19 < 0) {
		document.getElementById('t19').style.border = "1px solid #F94F4F"
	}
	if (e19 > 60 || e19 < 0) {
		document.getElementById('e19').style.border = "1px solid #F94F4F"
	}


	var cw20 = parseInt(document.getElementById('cw20').value);
	var a20 = parseInt(document.getElementById('a20').value);
	var t20 = parseInt(document.getElementById('t20').value);
	var e20 = parseInt(document.getElementById('e20').value);
	var Total20 = cw20 + a20 + t20 + e20;
	document.getElementById('total20').innerHTML=Total20;

	if(Total20 == 0 || Total20 <= 39){
		document.getElementById('grade20').innerHTML="F"
	}

	else if(Total20 == 40 || Total20 <= 44){
		document.getElementById('grade20').innerHTML="E"
	}

	else if(Total20 == 45 || Total20 <= 49){
		document.getElementById('grade20').innerHTML="D"
	}

	else if(Total20 == 50 || Total20 <= 59){
		document.getElementById('grade20').innerHTML="C"
	}

	else if(Total20 == 60 || Total20 <= 69){
		document.getElementById('grade20').innerHTML="B"
	}

	else if(Total20 == 70 || Total20 <= 84){
		document.getElementById('grade20').innerHTML="A"
	}

	else if(Total20 == 85 || Total20 <= 100){
		document.getElementById('grade20').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw20 > 10 || cw20 < 0) {
		document.getElementById('cw20').style.border = "1px solid #F94F4F"
	}
	if (a20 > 10 || a20 < 0) {
		document.getElementById('a20').style.border = "1px solid #F94F4F"
	}
	if (t20 > 20 || t20 < 0) {
		document.getElementById('t20').style.border = "1px solid #F94F4F"
	}
	if (e20 > 60 || e20 < 0) {
		document.getElementById('e20').style.border = "1px solid #F94F4F"
	}


	var cw21 = parseInt(document.getElementById('cw1').value);
	var a21 = parseInt(document.getElementById('a21').value);
	var t21 = parseInt(document.getElementById('t21').value);
	var e21 = parseInt(document.getElementById('e21').value);
	var Total21 = cw21 + a21 + t21 + e21 + 1;
	document.getElementById('total21').innerHTML=Total21;

	if(Total21 == 0 || Total21 <= 39){
		document.getElementById('grade21').innerHTML="F"
	}

	else if(Total21 == 40 || Total21 <= 44){
		document.getElementById('grade21').innerHTML="E"
	}

	else if(Total21 == 45 || Total21 <= 49){
		document.getElementById('grade21').innerHTML="D"
	}

	else if(Total21 == 50 || Total21 <= 59){
		document.getElementById('grade21').innerHTML="C"
	}

	else if(Total21 == 60 || Total21 <= 69){
		document.getElementById('grade21').innerHTML="B"
	}

	else if(Total21 == 70 || Total21 <= 84){
		document.getElementById('grade21').innerHTML="A"
	}

	else if(Total21 == 85 || Total21 <= 100){
		document.getElementById('grade21').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw21 > 10 || cw21 < 0) {
		document.getElementById('cw21').style.border = "1px solid #F94F4F"
	}
	if (a21 > 10 || a21 < 0) {
		document.getElementById('a21').style.border = "1px solid #F94F4F"
	}
	if (t21 > 20 || t21 < 0) {
		document.getElementById('t21').style.border = "1px solid #F94F4F"
	}
	if (e21 > 60 || e21 < 0) {
		document.getElementById('e21').style.border = "1px solid #F94F4F"
	}


	var cw22 = parseInt(document.getElementById('cw22').value);
	var a22 = parseInt(document.getElementById('a22').value);
	var t22 = parseInt(document.getElementById('t22').value);
	var e22 = parseInt(document.getElementById('e22').value);
	var Total22 = cw22 + a22 + t22 + e22;
	document.getElementById('total22').innerHTML=Total22;

	if(Total22 == 0 || Total22 <= 39){
		document.getElementById('grade22').innerHTML="F"
	}

	else if(Total22 == 40 || Total22 <= 44){
		document.getElementById('grade22').innerHTML="E"
	}

	else if(Total22 == 45 || Total22 <= 49){
		document.getElementById('grade22').innerHTML="D"
	}

	else if(Total22 == 50 || Total22 <= 59){
		document.getElementById('grade22').innerHTML="C"
	}

	else if(Total22 == 60 || Total22 <= 69){
		document.getElementById('grade22').innerHTML="B"
	}

	else if(Total22 == 70 || Total22 <= 84){
		document.getElementById('grade22').innerHTML="A"
	}

	else if(Total22 == 85 || Total22 <= 100){
		document.getElementById('grade22').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw22 > 10 || cw22 < 0) {
		document.getElementById('cw22').style.border = "1px solid #F94F4F"
	}
	if (a22 > 10 || a22 < 0) {
		document.getElementById('a22').style.border = "1px solid #F94F4F"
	}
	if (t22 > 20 || t22 < 0) {
		document.getElementById('t22').style.border = "1px solid #F94F4F"
	}
	if (e22 > 60 || e22 < 0) {
		document.getElementById('e22').style.border = "1px solid #F94F4F"
	}


    if (Total1 != 0) {
		n += 1
	}


    if (Total2 != 0) {
		n += 1
	}


    if (Total3 != 0) {
		n += 1
	}


    if (Total4 != 0) {
		n += 1
	}


    if (Total5 != 0) {
		n += 1
	}


    if (Total6 != 0) {
		n += 1
	}


    if (Total7 != 0) {
		n += 1
	}


    if (Total8 != 0) {
		n += 1
	}


    if (Total9 != 0) {
		n += 1
	}


    if (Total10 != 0) {
		n += 1
	}


    if (Total11 != 0) {
		n += 1
	}


    if (Total12 != 0) {
		n += 1
	}


    if (Total13 != 0) {
		n += 1
	}


    if (Total14 != 0) {
		n += 1
	}


    if (Total15 != 0) {
		n += 1

	}


    if (Total16 != 0) {
		n += 1
	}


    if (Total17 != 0) {
		n += 1
	}


    if (Total18 != 0) {
		n += 1
	}


    if (Total19 != 0) {
		n += 1
	}


    if (Total20 != 0) {
		n += 1
	}


    if (Total21 != 0) {
		n += 1
	}


	if (Total22 != 0) {
		n += 1
	}


    var Totals = Total1 + Total2 + Total3 + Total4 + Total5 + Total6 + Total7 + Total8 + Total9 + Total10 + Total11 + Total12 + Total13 + Total14 + Total15 + Total16 + Total17 + Total18 + Total19 + Total20 + Total21 + Total22 ;

    document.getElementById('totalALL').innerHTML= "<span style='font-size:15px	;'>Total: <br></span>" + Totals
    var averageMARK = Math.round(Totals/n)
    document.getElementById('average').innerHTML= "<span style='font-size:15px	;'>Average: <br></span>" + averageMARK

      if(averageMARK == 0 || averageMARK <= 39){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "F"
  }

  else if(averageMARK == 40 || averageMARK <= 44){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "E"
  }

  else if(averageMARK == 45 || averageMARK <= 49){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "D"
  }

  else if(averageMARK == 50 || averageMARK <= 59){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "C"
  }

  else if(averageMARK == 60 || averageMARK <= 69){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "B"
  }

  else if(averageMARK == 70 || averageMARK <= 84){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "A"
  }

  else if(averageMARK == 85 || averageMARK <= 100){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "A<sup>+</sup>"
  }

  else{
    
  } 




    
}
function jcalc() {
	var n = 0

	var cw1 = parseInt(document.getElementById('cw1').value);
	var a1 = parseInt(document.getElementById('a1').value);
	var t1 = parseInt(document.getElementById('t1').value);
	var e1 = parseInt(document.getElementById('e1').value);
	var Total1 = cw1 + a1 + t1 + e1;
	document.getElementById('total1').innerHTML=Total1;

	if(Total1 == 0 || Total1 <= 39){
		document.getElementById('grade1').innerHTML="F"
	}

	else if(Total1 == 40 || Total1 <= 44){
		document.getElementById('grade1').innerHTML="E"
	}

	else if(Total1 == 45 || Total1 <= 49){
		document.getElementById('grade1').innerHTML="D"
	}

	else if(Total1 == 50 || Total1 <= 59){
		document.getElementById('grade1').innerHTML="C"
	}

	else if(Total1 == 60 || Total1 <= 69){
		document.getElementById('grade1').innerHTML="B"
	}

	else if(Total1 == 70 || Total1 <= 84){
		document.getElementById('grade1').innerHTML="A"
	}

	else if(Total1 == 85 || Total1 <= 100){
		document.getElementById('grade1').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw1 > 10 || cw1 < 0) {
		document.getElementById('cw1').style.border = "1px solid #F94F4F"
	}
	if (a1 > 10 || a1 < 0) {
		document.getElementById('a1').style.border = "1px solid #F94F4F"
	}
	if (t1 > 20 || t1 < 0) {
		document.getElementById('t1').style.border = "1px solid #F94F4F"
	}
	if (e1 > 60 || e1 < 0) {
		document.getElementById('e1').style.border = "1px solid #F94F4F"
	}
	
	var cw2 = parseInt(document.getElementById('cw2').value);
	var a2 = parseInt(document.getElementById('a2').value);
	var t2 = parseInt(document.getElementById('t2').value);
	var e2 = parseInt(document.getElementById('e2').value);
	var Total2 = cw2 + a2 + t2 + e2;
	document.getElementById('total2').innerHTML=Total2;

	if(Total2 == 0 || Total2 <= 39){
			document.getElementById('grade2').innerHTML="F"
		}

		else if(Total2 == 40 || Total1 <= 44){
			document.getElementById('grade2').innerHTML="E"
		}

		else if(Total2 == 45 || Total2 <= 49){
			document.getElementById('grade2').innerHTML="D"
		}

		else if(Total2 == 50 || Total2 <= 59){
			document.getElementById('grade2').innerHTML="C"
		}

		else if(Total2 == 60 || Total1 <= 69){
			document.getElementById('grade2').innerHTML="B"
		}

		else if(Total2 == 70 || Total2 <= 84){
			document.getElementById('grade2').innerHTML="A"
		}

		else if(Total2 == 85 || Total1 <= 100){
			document.getElementById('grade2').innerHTML="A<sup>+</sup>"
		}

		else{
			
		} 
		if (cw2 > 10 || cw2 < 0) {
			document.getElementById('cw2').style.border = "1px solid #F94F4F"
		}
		if (a2 > 10 || a2 < 0) {
			document.getElementById('a2').style.border = "1px solid #F94F4F"
		}
		if (t2 > 20 || t2 < 0) {
			document.getElementById('t2').style.border = "1px solid #F94F4F"
		}
		if (e2 > 60 || e2 < 0) {
			document.getElementById('e2').style.border = "1px solid #F94F4F"
		}

	var cw3 = parseInt(document.getElementById('cw3').value);
	var a3 = parseInt(document.getElementById('a3').value);
	var t3 = parseInt(document.getElementById('t3').value);
	var e3 = parseInt(document.getElementById('e3').value);
	var Total3 = cw3 + a3 + t3 + e3;
	document.getElementById('total3').innerHTML=Total3;

	if(Total3 == 0 || Total3 <= 39){
		document.getElementById('grade3').innerHTML="F"
	}

	else if(Total3 == 40 || Total3 <= 44){
		document.getElementById('grade3').innerHTML="E"
	}

	else if(Total3 == 45 || Total3 <= 49){
		document.getElementById('grade3').innerHTML="D"
	}

	else if(Total3 == 50 || Total3 <= 59){
		document.getElementById('grade3').innerHTML="C"
	}

	else if(Total3 == 60 || Total3<= 69){
		document.getElementById('grade3').innerHTML="B"
	}

	else if(Total3 == 70 || Total3 <= 84){
		document.getElementById('grade3').innerHTML="A"
	}

	else if(Total3 == 85 || Total3 <= 100){
		document.getElementById('grade3').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw3 > 10 || cw3 < 0) {
		document.getElementById('cw3').style.border = "1px solid #F94F4F"
	}
	if (a3 > 10 || a3 < 0) {
		document.getElementById('a3').style.border = "1px solid #F94F4F"
	}
	if (t3 > 20 || t3 < 0) {
		document.getElementById('t3').style.border = "1px solid #F94F4F"
	}
	if (e3 > 60 || e3 < 0) {
		document.getElementById('e3').style.border = "1px solid #F94F4F"
	}

	var cw4 = parseInt(document.getElementById('cw4').value);
	var a4 = parseInt(document.getElementById('a4').value);
	var t4 = parseInt(document.getElementById('t4').value);
	var e4 = parseInt(document.getElementById('e4').value);
	var Total4 = cw4 + a4 + t4 + e4;
	document.getElementById('total4').innerHTML=Total4;

	if(Total4 == 0 || Total4 <= 39){
		document.getElementById('grade4').innerHTML="F"
	}

	else if(Total4 == 40 || Total4 <= 44){
		document.getElementById('grade4').innerHTML="E"
	}

	else if(Total4 == 45 || Total4 <= 49){
		document.getElementById('grade4').innerHTML="D"
	}

	else if(Total4 == 50 || Total4 <= 59){
		document.getElementById('grade4').innerHTML="C"
	}

	else if(Total4 == 60 || Total4 <= 69){
		document.getElementById('grade4').innerHTML="B"
	}

	else if(Total4 == 70 || Total4 <= 84){
		document.getElementById('grade4').innerHTML="A"
	}

	else if(Total4 == 85 || Total4 <= 100){
		document.getElementById('grade4').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw4 > 10 || cw4 < 0) {
		document.getElementById('cw4').style.border = "1px solid #F94F4F"
	}
	if (a4 > 10 || a4 < 0) {
		document.getElementById('a4').style.border = "1px solid #F94F4F"
	}
	if (t4 > 20 || t4 < 0) {
		document.getElementById('t4').style.border = "1px solid #F94F4F"
	}
	if (e4 > 60 || e4 < 0) {
		document.getElementById('e4').style.border = "1px solid #F94F4F"
	}

	var cw5 = parseInt(document.getElementById('cw5').value);
	var a5 = parseInt(document.getElementById('a5').value);
	var t5 = parseInt(document.getElementById('t5').value);
	var e5 = parseInt(document.getElementById('e5').value);
	var Total5 = cw5 + a5 + t5 + e5;
	document.getElementById('total5').innerHTML=Total5;

	if(Total1== 0 || Total5<= 39){
		document.getElementById('grade5').innerHTML="F"
	}

	else if(Total5== 40 || Total5<= 44){
		document.getElementById('grade5').innerHTML="E"
	}

	else if(Total5== 45 || Total5<= 49){
		document.getElementById('grade5').innerHTML="D"
	}

	else if(Total5== 50 || Total5<= 59){
		document.getElementById('grade5').innerHTML="C"
	}

	else if(Total5== 60 || Total5<= 69){
		document.getElementById('grade5').innerHTML="B"
	}

	else if(Total5== 70 || Total5<= 84){
		document.getElementById('grade5').innerHTML="A"
	}

	else if(Total5== 85 || Total5<= 100){
		document.getElementById('grade5').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw5> 10 || cw5< 0) {
		document.getElementById('cw5').style.border = "1px solid #F94F4F"
	}
	if (a5> 10 || a5< 0) {
		document.getElementById('a5').style.border = "1px solid #F94F4F"
	}
	if (t5> 20 || t5< 0) {
		document.getElementById('t5').style.border = "1px solid #F94F4F"
	}
	if (e5> 60 || e5< 0) {
		document.getElementById('e5').style.border = "1px solid #F94F4F"
	}

	var cw6 = parseInt(document.getElementById('cw6').value);
	var a6 = parseInt(document.getElementById('a6').value);
	var t6 = parseInt(document.getElementById('t6').value);
	var e6 = parseInt(document.getElementById('e6').value);
	var Total6 = cw6 + a6 + t6 + e6;
	document.getElementById('total6').innerHTML=Total6;

    if(Total6 == 0 || Total6 <= 39){
		document.getElementById('grade6').innerHTML="F"
	}

	else if(Total6 == 40 || Total6 <= 44){
		document.getElementById('grade6').innerHTML="E"
	}

	else if(Total6 == 45 || Total6 <= 49){
		document.getElementById('grade6').innerHTML="D"
	}

	else if(Total6 == 50 || Total6 <= 59){
		document.getElementById('grade6').innerHTML="C"
	}

	else if(Total6 == 60 || Total6 <= 69){
		document.getElementById('grade6').innerHTML="B"
	}

	else if(Total6 == 70 || Total6 <= 84){
		document.getElementById('grade6').innerHTML="A"
	}

	else if(Total6 == 85 || Total6 <= 100){
		document.getElementById('grade6').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw6 > 10 || cw6 < 0) {
		document.getElementById('cw6').style.border = "1px solid #F94F4F"
	}
	if (a6 > 10 || a6 < 0) {
		document.getElementById('a6').style.border = "1px solid #F94F4F"
	}
	if (t6 > 20 || t6 < 0) {
		document.getElementById('t6').style.border = "1px solid #F94F4F"
	}
	if (e6 > 60 || e6 < 0) {
		document.getElementById('e6').style.border = "1px solid #F94F4F"
	}

	var cw7 = parseInt(document.getElementById('cw7').value);
	var a7 = parseInt(document.getElementById('a7').value);
	var t7 = parseInt(document.getElementById('t7').value);
	var e7 = parseInt(document.getElementById('e7').value);
	var Total7 = cw7 + a7 + t7 + e7;
	document.getElementById('total7').innerHTML=Total7;

if(Total7 == 0 || Total7 <= 39){
		document.getElementById('grade7').innerHTML="F"
	}

	else if(Total7 == 40 || Total7 <= 44){
		document.getElementById('grade7').innerHTML="E"
	}

	else if(Total7 == 45 || Total7 <= 49){
		document.getElementById('grade7').innerHTML="D"
	}

	else if(Total7 == 50 || Total7 <= 59){
		document.getElementById('grade7').innerHTML="C"
	}

	else if(Total7 == 60 || Total7 <= 69){
		document.getElementById('grade7').innerHTML="B"
	}

	else if(Total7 == 70 || Total7 <= 84){
		document.getElementById('grade7').innerHTML="A"
	}

	else if(Total7 == 85 || Total7 <= 100){
		document.getElementById('grade7').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw7 > 10 || cw7 < 0) {
		document.getElementById('cw7').style.border = "1px solid #F94F4F"
	}
	if (a7 > 10 || a7 < 0) {
		document.getElementById('a7').style.border = "1px solid #F94F4F"
	}
	if (t7 > 20 || t7 < 0) {
		document.getElementById('t7').style.border = "1px solid #F94F4F"
	}
	if (e7 > 60 || e7 < 0) {
		document.getElementById('e7').style.border = "1px solid #F94F4F"
	}

	var cw8 = parseInt(document.getElementById('cw8').value);
	var a8 = parseInt(document.getElementById('a8').value);
	var t8 = parseInt(document.getElementById('t8').value);
	var e8 = parseInt(document.getElementById('e8').value);
	var Total8 = cw8 + a8 + t8 + e8;
	document.getElementById('total8').innerHTML=Total8;

	if(Total8 == 0 || Total8 <= 39){
		document.getElementById('grade8').innerHTML="F"
	}

	else if(Total8 == 40 || Total8 <= 44){
		document.getElementById('grade8').innerHTML="E"
	}

	else if(Total8 == 45 || Total8 <= 49){
		document.getElementById('grade8').innerHTML="D"
	}

	else if(Total8 == 50 || Total8 <= 59){
		document.getElementById('grade8').innerHTML="C"
	}

	else if(Total8 == 60 || Total8 <= 69){
		document.getElementById('grade8').innerHTML="B"
	}

	else if(Total8 == 70 || Total8 <= 84){
		document.getElementById('grade8').innerHTML="A"
	}

	else if(Total8 == 85 || Total8 <= 100){
		document.getElementById('grade8').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw8 > 10 || cw8 < 0) {
		document.getElementById('cw8').style.border = "1px solid #F94F4F"
	}
	if (a8 > 10 || a8 < 0) {
		document.getElementById('a8').style.border = "1px solid #F94F4F"
	}
	if (t8 > 20 || t8 < 0) {
		document.getElementById('t8').style.border = "1px solid #F94F4F"
	}
	if (e8 > 60 || e8 < 0) {
		document.getElementById('e8').style.border = "1px solid #F94F4F"
	}

	var cw9 = parseInt(document.getElementById('cw9').value);
	var a9 = parseInt(document.getElementById('a9').value);
	var t9 = parseInt(document.getElementById('t9').value);
	var e9 = parseInt(document.getElementById('e9').value);
	var Total9 = cw9 + a9 + t9 + e9;
	document.getElementById('total9').innerHTML=Total9;

	if(Total9 == 0 || Total9 <= 39){
		document.getElementById('grade9').innerHTML="F"
	}

	else if(Total9 == 40 || Total9 <= 44){
		document.getElementById('grade9').innerHTML="E"
	}

	else if(Total9 == 45 || Total9 <= 49){
		document.getElementById('grade9').innerHTML="D"
	}

	else if(Total9 == 50 || Total9 <= 59){
		document.getElementById('grade9').innerHTML="C"
	}

	else if(Total9 == 60 || Total9 <= 69){
		document.getElementById('grade9').innerHTML="B"
	}

	else if(Total9 == 70 || Total9 <= 84){
		document.getElementById('grade9').innerHTML="A"
	}

	else if(Total9 == 85 || Total9 <= 100){
		document.getElementById('grade9').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw9 > 10 || cw9 < 0) {
		document.getElementById('cw9').style.border = "1px solid #F94F4F"
	}
	if (a9 > 10 || a9 < 0) {
		document.getElementById('a9').style.border = "1px solid #F94F4F"
	}
	if (t9 > 20 || t9 < 0) {
		document.getElementById('t9').style.border = "1px solid #F94F4F"
	}
	if (e9 > 60 || e9 < 0) {
		document.getElementById('e9').style.border = "1px solid #F94F4F"
	}

	var cw10 = parseInt(document.getElementById('cw10').value);
	var a10 = parseInt(document.getElementById('a10').value);
	var t10 = parseInt(document.getElementById('t10').value);
	var e10 = parseInt(document.getElementById('e10').value);
	var Total10 = cw10 + a10 + t10 + e10;
	document.getElementById('total10').innerHTML=Total10;

	if(Total10 == 0 || Total10 <= 39){
		document.getElementById('grade10').innerHTML="F"
	}

	else if(Total10 == 40 || Total10 <= 44){
		document.getElementById('grade10').innerHTML="E"
	}

	else if(Total10 == 45 || Total10 <= 49){
		document.getElementById('grade10').innerHTML="D"
	}

	else if(Total10 == 50 || Total10 <= 59){
		document.getElementById('grade10').innerHTML="C"
	}

	else if(Total10 == 60 || Total10 <= 69){
		document.getElementById('grade10').innerHTML="B"
	}

	else if(Total10 == 70 || Total10 <= 84){
		document.getElementById('grade10').innerHTML="A"
	}

	else if(Total10 == 85 || Total10 <= 100){
		document.getElementById('grade10').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw10 > 10 || cw10 < 0) {
		document.getElementById('cw10').style.border = "1px solid #F94F4F"
	}
	if (a10 > 10 || a10 < 0) {
		document.getElementById('a10').style.border = "1px solid #F94F4F"
	}
	if (t10 > 20 || t10 < 0) {
		document.getElementById('t10').style.border = "1px solid #F94F4F"
	}
	if (e10 > 60 || e10 < 0) {
		document.getElementById('e10').style.border = "1px solid #F94F4F"
	}

	var cw11 = parseInt(document.getElementById('cw11').value);
	var a11 = parseInt(document.getElementById('a11').value);
	var t11 = parseInt(document.getElementById('t11').value);
	var e11 = parseInt(document.getElementById('e11').value);
	var Total11 = cw11 + a11 + t11 + e11;
	document.getElementById('total11').innerHTML=Total11;

	if(Total11 == 0 || Total11 <= 39){
		document.getElementById('grade11').innerHTML="F"
	}

	else if(Total11 == 40 || Total11 <= 44){
		document.getElementById('grade11').innerHTML="E"
	}

	else if(Total11 == 45 || Total11 <= 49){
		document.getElementById('grade11').innerHTML="D"
	}

	else if(Total11 == 50 || Total11 <= 59){
		document.getElementById('grade11').innerHTML="C"
	}

	else if(Total11 == 60 || Total11 <= 69){
		document.getElementById('grade11').innerHTML="B"
	}

	else if(Total11 == 70 || Total11 <= 84){
		document.getElementById('grade11').innerHTML="A"
	}

	else if(Total11 == 85 || Total11 <= 100){
		document.getElementById('grade11').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw11 > 10 || cw11 < 0) {
		document.getElementById('cw11').style.border = "1px solid #F94F4F"
	}
	if (a11 > 10 || a11 < 0) {
		document.getElementById('a11').style.border = "1px solid #F94F4F"
	}
	if (t11 > 20 || t11 < 0) {
		document.getElementById('t11').style.border = "1px solid #F94F4F"
	}
	if (e11 > 60 || e11 < 0) {
		document.getElementById('e11').style.border = "1px solid #F94F4F"
	}

	var cw12 = parseInt(document.getElementById('cw12').value);
	var a12 = parseInt(document.getElementById('a12').value);
	var t12 = parseInt(document.getElementById('t12').value);
	var e12 = parseInt(document.getElementById('e12').value);
	var Total12 = cw12 + a12 + t12 + e12;
	document.getElementById('total12').innerHTML=Total12;

	if(Total12 == 0 || Total12 <= 39){
		document.getElementById('grade12').innerHTML="F"
	}

	else if(Total12 == 40 || Total12 <= 44){
		document.getElementById('grade12').innerHTML="E"
	}

	else if(Total12 == 45 || Total12 <= 49){
		document.getElementById('grade12').innerHTML="D"
	}

	else if(Total12 == 50 || Total12 <= 59){
		document.getElementById('grade12').innerHTML="C"
	}

	else if(Total12 == 60 || Total12 <= 69){
		document.getElementById('grade12').innerHTML="B"
	}

	else if(Total12 == 70 || Total12 <= 84){
		document.getElementById('grade12').innerHTML="A"
	}

	else if(Total12 == 85 || Total12 <= 100){
		document.getElementById('grade12').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw12 > 10 || cw12 < 0) {
		document.getElementById('cw12').style.border = "1px solid #F94F4F"
	}
	if (a12 > 10 || a12 < 0) {
		document.getElementById('a12').style.border = "1px solid #F94F4F"
	}
	if (t12 > 20 || t12 < 0) {
		document.getElementById('t12').style.border = "1px solid #F94F4F"
	}
	if (e12 > 60 || e12 < 0) {
		document.getElementById('e12').style.border = "1px solid #F94F4F"
	}

	var cw13 = parseInt(document.getElementById('cw13').value);
	var a13 = parseInt(document.getElementById('a13').value);
	var t13 = parseInt(document.getElementById('t13').value);
	var e13 = parseInt(document.getElementById('e13').value);
	var Total13 = cw13 + a13 + t13 + e13;
	document.getElementById('total13').innerHTML=Total13;

	if(Total13 == 0 || Total13 <= 39){
		document.getElementById('grade13').innerHTML="F"
	}

	else if(Total13 == 40 || Total13 <= 44){
		document.getElementById('grade13').innerHTML="E"
	}

	else if(Total13 == 45 || Total13 <= 49){
		document.getElementById('grade13').innerHTML="D"
	}

	else if(Total13 == 50 || Total13 <= 59){
		document.getElementById('grade13').innerHTML="C"
	}

	else if(Total13 == 60 || Total13 <= 69){
		document.getElementById('grade13').innerHTML="B"
	}

	else if(Total13 == 70 || Total13 <= 84){
		document.getElementById('grade13').innerHTML="A"
	}

	else if(Total13 == 85 || Total13 <= 100){
		document.getElementById('grade13').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw13 > 10 || cw13 < 0) {
		document.getElementById('cw13').style.border = "1px solid #F94F4F"
	}
	if (a13 > 10 || a13 < 0) {
		document.getElementById('a13').style.border = "1px solid #F94F4F"
	}
	if (t13 > 20 || t13 < 0) {
		document.getElementById('t13').style.border = "1px solid #F94F4F"
	}
	if (e13 > 60 || e13 < 0) {
		document.getElementById('e13').style.border = "1px solid #F94F4F"
	}


	var cw14 = parseInt(document.getElementById('cw14').value);
	var a14 = parseInt(document.getElementById('a14').value);
	var t14 = parseInt(document.getElementById('t14').value);
	var e14 = parseInt(document.getElementById('e14').value);
	var Total14 = cw14 + a14 + t14 + e14;
	document.getElementById('total14').innerHTML=Total14;

		if(Total14 == 0 || Total14 <= 39){
		document.getElementById('grade14').innerHTML="F"
	}

	else if(Total14 == 40 || Total14 <= 44){
		document.getElementById('grade14').innerHTML="E"
	}

	else if(Total14 == 45 || Total14 <= 49){
		document.getElementById('grade14').innerHTML="D"
	}

	else if(Total14 == 50 || Total14 <= 59){
		document.getElementById('grade14').innerHTML="C"
	}

	else if(Total14 == 60 || Total14 <= 69){
		document.getElementById('grade14').innerHTML="B"
	}

	else if(Total14 == 70 || Total14 <= 84){
		document.getElementById('grade14').innerHTML="A"
	}

	else if(Total14 == 85 || Total14 <= 100){
		document.getElementById('grade14').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw14 > 10 || cw14 < 0) {
		document.getElementById('cw14').style.border = "1px solid #F94F4F"
	}
	if (a14 > 10 || a14 < 0) {
		document.getElementById('a14').style.border = "1px solid #F94F4F"
	}
	if (t14 > 20 || t14 < 0) {
		document.getElementById('t14').style.border = "1px solid #F94F4F"
	}
	if (e14 > 60 || e14 < 0) {
		document.getElementById('e14').style.border = "1px solid #F94F4F"
	}

	var cw15 = parseInt(document.getElementById('cw15').value);
	var a15 = parseInt(document.getElementById('a15').value);
	var t15 = parseInt(document.getElementById('t15').value);
	var e15 = parseInt(document.getElementById('e15').value);
	var Total15 = cw15 + a15 + t15 + e15;
	document.getElementById('total15').innerHTML=Total15;

		if(Total15 == 0 || Total15 <= 39){
		document.getElementById('grade15').innerHTML="F"
	}

	else if(Total15 == 40 || Total15 <= 44){
		document.getElementById('grade15').innerHTML="E"
	}

	else if(Total15 == 45 || Total15 <= 49){
		document.getElementById('grade15').innerHTML="D"
	}

	else if(Total15 == 50 || Total15 <= 59){
		document.getElementById('grade15').innerHTML="C"
	}

	else if(Total15 == 60 || Total15 <= 69){
		document.getElementById('grade15').innerHTML="B"
	}

	else if(Total15 == 70 || Total15 <= 84){
		document.getElementById('grade15').innerHTML="A"
	}

	else if(Total15 == 85 || Total15 <= 1100){
		document.getElementById('grade15').innerHTML="A<sup>+</sup>"
	}

	else{
		
	} 
	if (cw15 > 10 || cw15 < 0) {
		document.getElementById('cw15').style.border = "1px solid #F94F4F"
	}
	if (a15 > 10 || a15 < 0) {
		document.getElementById('a15').style.border = "1px solid #F94F4F"
	}
	if (t15 > 20 || t15 < 0) {
		document.getElementById('t15').style.border = "1px solid #F94F4F"
	}
	if (e15 > 60 || e15 < 0) {
		document.getElementById('e15').style.border = "1px solid #F94F4F"
	}

	


    if (Total1 != 0) {
		n += 1
	}


    if (Total2 != 0) {
		n += 1
	}


    if (Total3 != 0) {
		n += 1
	}


    if (Total4 != 0) {
		n += 1
	}


    if (Total5 != 0) {
		n += 1
	}


    if (Total6 != 0) {
		n += 1
	}


    if (Total7 != 0) {
		n += 1
	}


    if (Total8 != 0) {
		n += 1
	}


    if (Total9 != 0) {
		n += 1
	}


    if (Total10 != 0) {
		n += 1
	}


    if (Total11 != 0) {
		n += 1
	}


    if (Total12 != 0) {
		n += 1
	}


    if (Total13 != 0) {
		n += 1
	}


    if (Total14 != 0) {
		n += 1
	}


    if (Total15 != 0) {
		n += 1

	}




    var Totals = Total1 + Total2 + Total3 + Total4 + Total5 + Total6 + Total7 + Total8 + Total9 + Total10 + Total11 + Total12 + Total13 + Total14 + Total15;

    document.getElementById('totalALL').innerHTML= "<span style='font-size:15px	;'>Total: <br></span>" + Totals
    var averageMARK = Math.round(Totals/n)
    document.getElementById('average').innerHTML= "<span style='font-size:15px	;'>Average: <br></span>" + averageMARK

      if(averageMARK == 0 || averageMARK <= 39){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "F"
  }

  else if(averageMARK == 40 || averageMARK <= 44){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "E"
  }

  else if(averageMARK == 45 || averageMARK <= 49){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "D"
  }

  else if(averageMARK == 50 || averageMARK <= 59){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "C"
  }

  else if(averageMARK == 60 || averageMARK <= 69){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "B"
  }

  else if(averageMARK == 70 || averageMARK <= 84){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "A"
  }

  else if(averageMARK == 85 || averageMARK <= 100){
    document.getElementById('gradeALL').innerHTML="<span style='font-size:15px	;'>Avg-Grade: <br></span>" + "A<sup>+</sup>"
  }

  else{
    
  } 




    
}
var myVar;

function myFunction() {
    myVar = setTimeout(showPage, 3000);
}
myFunction()
function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("loaderText").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}